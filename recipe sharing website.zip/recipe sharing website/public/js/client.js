// this is the login function 
 async function displaylog(){
    let username = document.getElementById ('usern').value;
    let password = document.getElementById ('passu').value;

    const data ={ username, password };
    const options = {
        method: 'POST',
        headers: {
            'Content-Type' : 'application/json'
        },
        body: JSON.stringify(data)
    };
    const response = await fetch('/checklogin', options);
    const json = await response.json();
    const status = json.status;
    console.log (status);
    if (status == 'success'){
        sessionStorage.setItem("loggedinuser", username);
        window.location = 'home.html';
    }else{
        alert ('Wrong user name or password');
    }
    

    console.log.json

    
  
};


// this is the register function 
async function insertreg(){
    let username = document.getElementById ('nmeuse').value;
    let firstname = document.getElementById ('firstn').value;
    let lastname = document.getElementById ('lastn').value;
    let password = document.getElementById ('passwrd').value;

    const data ={ username, firstname,lastname, password };
    const options = {
        method: 'POST',
        headers: {
            'Content-Type' : 'application/json'
        },
        body: JSON.stringify(data)
    };
    const response = await fetch('/compreg', options);
    const json = await response.json();
    const status = json.status;
    console.log (status);
    if (status == 'success'){
        sessionStorage.setItem("loggedinuser", username);
        window.location = 'home.html';
    }else{
        alert ('Cannot create account change username');
    }
    
    console.log.json
  
};

// This is the upload rescipe function 
async function uploadres(){
    let Image = document.getElementById ('resimg').value;
    let Recipe = document.getElementById ('rescr').value;
    let Name = document.getElementById ('rescpn').value;
    let Desc = document.getElementById ('rescpd').value;

    const data ={ Image, Recipe, Name, Desc };
    const options = {
        method: 'POST',
        headers: {
            'Content-Type' : 'application/json'
        },
        body: JSON.stringify(data)
    };
    const response = await fetch('/freeupload', options);
    const json = await response.json();
    console.log.json
  
};

// recipe display function 
async function Resdisplay(){
    const options = {
        method: 'POST',
        headers: {
            'Content-Type' : 'application/json'
        },
       
    };
    const response = await fetch('/disres', options);
    const json = await response.json();
    console.log.json
    let data =   JSON.parse(json.data) 
    document.getElementById('recipepage').innerHTML ="";
    data.forEach(function (arrayItem) {
      
     // setting a data type for the image upload function    
    let block = '<div class="recp"> <img id="disimg" src="images/'+ arrayItem.Image +'" > <div class="resdet">'
    + '<p id="disres"> Recipe: '+ arrayItem.Recipe +'</p> <p id="disname"> Name: '+ arrayItem.Name +'</p> '+
        '<p id="disdesc"> Desc: '+ arrayItem.Desc +'</p></div></div>'    
        
        let div = document.getElementById('recipepage');
        div.innerHTML += block;

    });
    
};

