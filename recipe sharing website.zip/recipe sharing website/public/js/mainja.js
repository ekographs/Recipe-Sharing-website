// this function hides login and register page if user is logged in and it shows the logout button
var loggedinuser = sessionStorage.getItem("loggedinuser");
if (loggedinuser) {
    document.getElementById("logid").style.display = "none";
    document.getElementById("regid").style.display = "none";
} else{
    document.getElementById("outid").style.display = "none";
}
// this function gets all the pages, loops through them and set the display type to hidden. 
function show(page) {
    if(page== 'uploadpage'){
        var loggedinuser = sessionStorage.getItem("loggedinuser");

        if(!loggedinuser){
            page = 'loginpage';
        }

    }
    var pages = document.getElementsByClassName("page");

    Array.prototype.forEach.call(pages, function(p) {
        p.style.display = "none";
    });
   
    

    // this function shows the current page with hash on the browser 
document.getElementById(page).style.display = "block";
if (page == 'recipepage'){
    Resdisplay();
}
}

// this function changes the displays the hash on the current page

if(window.location.hash) {
    var hash = window.location.hash.substring(1);
    show(hash);

 
  }
  
  document.getElementById("resshow").addEventListener("click", function(){Resdisplay()});

    // function is for login 
      
    function logout() {
        sessionStorage.removeItem("loggedinuser");
        window.location = 'home.html';
    }


    function loginSubmit(){
        return false;
        }
        

        function butrespond(){
            alert ('Thank you for reaching out to us we will get back to you');
            document.getElementById('namecnt').value ="";
            document.getElementById('emailcnt').value ="";
            document.getElementById('smg').value =""; 
        }