//Import the express module
const express = require('express');
const multer = require('multer');
const ejs = require('ejs');
const path = require('path');


//The express module is a function. When it is executed it returns an app object
const app = express();

// EJS 
app.set('view engine', 'ejs'); 

//Set up express to serve static files from the directory called 'public'
app.use(express.static('public'));



//Start the app listening on port 8082
const port = 8082;

app.listen(port, () => console.log(`Server started on port ${port}`));

// Collect values from the client side 
const bodyparser = require('body-parser');
app.use(bodyparser.json());


//let formidable = require('formidable');




//Import the mysql module
const mysql = require('mysql');

//Create a connection pool with the user details
const connectionPool = mysql.createPool({
    connectionLimit: 1,
    host: "localhost",
    user: "root",
    password: "",
    database: "recipe",
    debug: false
});




function checklogin(){
    let resi = "error";

    app.post('/checklogin', (request, response) => {
        let username = request.body.username
        let password = request.body.password
        
    
        //Build query
    let sql = "select * from users where username = '"+ username +"' and password  = '"+ password +"'";
    
    //Execute query and output results
    connectionPool.query(sql, (err, result) => {
    if (err){//Check for errors
        console.error("Error executing query: " + JSON.stringify(err));
        response.json( {
            status: 'error'
        
        });
    }
    else{// if no errors displays results
        console.log(JSON.stringify(result));
    
        if (result.length > 0) {
            resi = "success"
            console.log (resi);
        }
        else {
           resi = "error";
        }
        response.json( {
            status: resi
        
        });
    }
    });
   
    });
}
checklogin();

// this function is to compile the registration progress in the server 
function compreg(){


    app.post('/compreg', (request, response) => {
        let username = request.body.username
        let firstname = request.body.firstname
        let lastname = request.body.lastname
        let password = request.body.password
        
    
        //Build query
 let sql = "INSERT INTO users  " +
        "VALUES ('"+ username +"', '" +firstname +"', '"+lastname+"' ,'"+ password + "')";
    
    //Execute query and output results
    connectionPool.query(sql, (err, result) => {
    if (err){//Check for errors
        console.error("Error executing query: " + JSON.stringify(err));
        response.json( {
            status: 'error'
        
        });
    }
    else{// if no errors displays results
        console.log(JSON.stringify(result));
        response.json( {
            status: 'success'
        
        });
    }
    });
    
    });
}
compreg();


// this function is for uploading recipe 
    function freeupload(){
        const storage = multer.diskStorage({
            destination: './public/images/',
            filename: function(request, file, cb){ //this function takes in the file name the request and the callback
                cb(null,file.fieldname + '-' + Date.now() +
                path.extname(file.originalname));     //this function changes the name of the image when uploaded and a timeframe 
            }                       
            });
        // Init Upload 
    const upload = multer({
        storage: storage 
    }).single('imageToUpload');

    app.post('/freeupload', (request, response) => {

  // app.get('/', (request, response) => response.render('home'));

    
        upload(request, response, (err) => {
            if(err){
                response.render('home', {
                    msg: err
                });
            } else {
                let Image = request.file.filename
                let Recipe = request.body.rep
                let Name = request.body.resname
                let Desc = request.body.resdesc
                
            
                //Build query
         let sql = "INSERT INTO recp  " +
                "VALUES ('"+ Image +"', '" +Recipe +"', '"+Name+"' ,'"+ Desc + "')";
            
           // Execute query and output results
            connectionPool.query(sql, (err, result) => {
            if (err){//Check for errors
                console.error("Error executing query: " + JSON.stringify(err));
            }
            else{// if no errors displays results
                console.log(JSON.stringify(result));
            }
            });
                
            }
    });

    // Setting storage Engine 
    
       
    response.writeHead(302, {
        'Location': 'home.html#recipepage'
        //add other headers here...
      });
      response.end();
      
    });
}
freeupload();



// this is the function for displaying the recipes on the recipe

function disres(){

    
    app.post('/disres', (request, response) => {
        
    
        //Build query
 let sql = "select * from recp ";       

    
    //Execute query and output results
    connectionPool.query(sql, (err, result) => {
    if (err){//Check for errors
        console.error("Error executing query: " + JSON.stringify(err));
        const answer = false;
        response.json( {
            status: 'success' , data:answer
        
        });
        
       
    }
    else{// if no errors displays results
        const answer = JSON.stringify(result);
        console.log(JSON.stringify(result));
        response.json( {
            status: 'success' , data:answer
        
        });
       

    }
    });
    
    });
}
disres(); 




